innosms.example.php
===================

Messaging Service API Example for PHP
