<?php header("Content-type:text/html;charset=utf-8"); ?>
<!DOCTYPE html>
<html>
<head>
	<title>API Client</title>
</head>
 <body>
	<a href="GetBalance.php">잔여금액 조회</a><br>
	<a href="SendSMS.php">SMS전송</a><br>
	<a href="SendLMS.php">LMS전송</a><br>
	<a href="SendMMS.php">MMS전송</a><br>
	<a href="GetMessage.php">전송내역 조회</a><br>
	<a href="CancelReservation.php">예약내역 취소</a><br><br>
 </body>
</html>