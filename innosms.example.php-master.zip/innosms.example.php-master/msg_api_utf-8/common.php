<?php

header("Content-Type: text/html; charset=UTF-8");

require_once 'lib/MessagingService.php';

//발급받은 API 아이디
$client_id = "발급받은 API 아이디";

//발급받은 API키
$api_key = "발급받은 API키";

?>